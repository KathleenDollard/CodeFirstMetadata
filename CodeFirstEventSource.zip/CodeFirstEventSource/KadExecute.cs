﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KadGen.Common;
using System.IO;

namespace KadGen.KadEventSource
{
    public class KadExecute
    {
        public static bool Run(string extension,
             string patternName,
             out string[] outputFiles,
             params string[] sources)
        {
            if (!extension.StartsWith(".")) { extension = "." + extension; }
            var outputs = new List<string>();
            foreach (var inFileName in sources)
            {
                // Switch to regex, but for now use extension
                if (Path.GetExtension(inFileName).Equals (extension, StringComparison.OrdinalIgnoreCase ))
                {
                    var outFileName = Path.ChangeExtension(inFileName, ".g.cs");
                    outputs.Add(outFileName);
                    // TODO: Use MEF to retieve the pattern based on the pattern name
                    if (patternName != "KadEventSource")
                    { throw new InvalidOperationException("You must use the PatternName 'KadEventSource''"); }
                    var eventSources = KadExecute.ProcessFile(inFileName);
                    var output = ""; // stringbuilder not used because 1 is the common case, less than ten in all cases
                    foreach (var eventSource in eventSources)
                    {
                        eventSource.ValidateAndUpdate();
                        output += KadExecute.GenerateFile(eventSource);
                    }
                    File.WriteAllText(outFileName, output);
                }
            }
            outputFiles = outputs.ToArray();
            return true;
        }

        public static IEnumerable<KadEventSource> ProcessFile(string path)
        {
            var text = FileSupport.GetFileContents(path);
            var parser = new KadGen.Common.Roslyn.ParserForMetadata<KadEventSource>();
            var result = parser.Parse(text);
            return result;
        }

        public static string GenerateFile(KadEventSource kadEventSource)
        {
            var template = new KadMan_EventSource();
            template.Meta = kadEventSource;
            var ret = template.TransformText();
            return ret;
        }
    }
}
